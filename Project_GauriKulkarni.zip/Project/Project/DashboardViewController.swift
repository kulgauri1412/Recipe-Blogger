//
//  DashboardViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/5/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class DashboardViewController: UIViewController {
    
    deinit {
            print("No retain cycle/leak")
    }
    //firebase database category reference
    var categoryRef : DatabaseReference?
    
    //Recipe buttons for particular category
    
    @IBAction func btnAmerican(_ sender: Any) {
        categoryRef?.child("American").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
              
        if snapshot.childrenCount > 0 {
            let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "American"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            }
              
        })
    }
    
    
    @IBAction func btnImgAmerican(_ sender: Any) {
        categoryRef?.child("American").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
              
        if snapshot.childrenCount > 0 {
            let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "American"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            }
              
        })
    }
    
    @IBAction func btnImgChinese(_ sender: Any) {
        categoryRef?.child("Chinese").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
                  
            if snapshot.childrenCount > 0 {
                let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
                vc.cuisinename = "Chinese"
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                }
                  
        })
    }
    
    @IBAction func btnChinese(_ sender: Any) {
        categoryRef?.child("Chinese").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
            
            if snapshot.childrenCount > 0 {
                 let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
                vc.cuisinename = "Chinese"
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
               alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
               self.present(alert, animated: true, completion: nil)
            }
            
        })
    }
    
    @IBAction func btnItalian(_ sender: Any) {
        categoryRef?.child("Italian").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
            
            if snapshot.childrenCount > 0 {
                 let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
                vc.cuisinename = "Italian"
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else{
                let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
               alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
               self.present(alert, animated: true, completion: nil)
            }
            
        })

    }
    
    @IBAction func btnImgItalian(_ sender: Any) {
        categoryRef?.child("Italian").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
        
        if snapshot.childrenCount > 0 {
             let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "Italian"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
    })
    }
    
    @IBAction func btnImgIndian(_ sender: Any) {
    categoryRef?.child("Indian").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
        
        if snapshot.childrenCount > 0 {
             let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "Indian"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
        })
    }
    
    @IBAction func btnIndian(_ sender: Any) {
    categoryRef?.child("Indian").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
    
    if snapshot.childrenCount > 0 {
         let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
        vc.cuisinename = "Indian"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    else{
        let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
       alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
       self.present(alert, animated: true, completion: nil)
        }
    
        })
    }
    
    @IBAction func btnImgMexican(_ sender: Any) {
    categoryRef?.child("Mexican").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
    
    if snapshot.childrenCount > 0 {
         let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
        vc.cuisinename = "Mexican"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    else{
        let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
       alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
       self.present(alert, animated: true, completion: nil)
    }
    
    })
    }
    
    @IBAction func btnMexican(_ sender: Any) {
        categoryRef?.child("Mexican").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
        
        if snapshot.childrenCount > 0 {
             let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "Mexican"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
        })
    }
    
    @IBAction func btnImgOther(_ sender: Any) {
        categoryRef?.child("Other").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
        
        if snapshot.childrenCount > 0 {
             let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "Other"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            print("Inside other else")
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
        })
    }
    @IBAction func btnOther(_ sender: Any) {
        categoryRef?.child("Other").child("Posts").observeSingleEvent(of: .value, with:{(snapshot) in
        
        if snapshot.childrenCount > 0 {
             let vc = self.storyboard?.instantiateViewController(identifier: "FoodCategoryListVC") as! FoodCategoryListVC
            vc.cuisinename = "Other"
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "No recipe added yet!", message: "", preferredStyle: UIAlertController.Style.alert)
           alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
           self.present(alert, animated: true, completion: nil)
        }
        
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //Need to call firebase on this method
    override func viewWillAppear(_ animated: Bool) {
        categoryRef = Database.database().reference().child("Category")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        categoryRef = nil
    }

    
}
