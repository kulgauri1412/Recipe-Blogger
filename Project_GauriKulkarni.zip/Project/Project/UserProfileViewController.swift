//
//  UserProfileViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/4/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class UserProfileViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,buttonProtocol{
    
    //firebase database reference
    var userRef : DatabaseReference?
   
    var userDetail = [UserModel]()
    var posts = [PostModel]()
    //post ids from users
    var postIds = [String]()
    
    @IBOutlet weak var usertabelview: UITableView!
    
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var postcount: UILabel!
    
    
    @IBAction func btnLogout(_ sender: Any) {
        try! Auth.auth().signOut()     
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
         vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        URLCache.shared.removeAllCachedResponses()
        userRef = Database.database().reference()
        
        
        //fetch detail from firebase users
        userRef?.child("Users").observe(.value, with: {(snapshot) in
            if snapshot.childrenCount > 0{
                  self.userDetail.removeAll()
                for user in snapshot.children.allObjects as! [DataSnapshot]{
                   let userdetails = user.value as! [String: AnyObject]
                   // print(userdetails)
                    let uid = userdetails["id"] as! String
                    let userId = Auth.auth().currentUser!.uid
                    //print(userId)
                    //(uid)
                    
                    if uid == userId {
                        //get user information post count
                        let username = userdetails["username"] as! String

                        let posts = userdetails["Posts"]
                        let count = posts?.count
                        self.username.text = username
                        if count != nil{
                          self.postcount.text = "Posts: \(count!)"
                        }else{
                          self.postcount.text = "Posts: 0"
                        }
                    
                    }
                    
                }
            }
            else{
                print("no data")
            }
            
        })
        
      userRef?.child("Posts").observe(.value, with: {(snapshot) in
         if snapshot.childrenCount > 0{
                   self.posts.removeAll()
                   //remove all data from model to avoid duplicate entry
                   for user in snapshot.children.allObjects as! [DataSnapshot]{
                      let userpostdetails = user.value as? [String: AnyObject]
                      let puid = userpostdetails!["uid"] as! String
                      let userId = Auth.auth().currentUser!.uid
                       
                       if puid == userId {
                           print("Post found Inside userprofile controller",puid)
                           
                           let recipename = userpostdetails?["recipename"]
                           let preptimehr = userpostdetails?["preptimehr"]
                           let preptimemin = userpostdetails?["preptimemin"]
                           let serving = userpostdetails?["serving"]
                           let level = userpostdetails?["setlevel"]
                           let category = userpostdetails?["category"]
                           let instruction = userpostdetails?["instruction"]
                           let imgurl = userpostdetails?["imageUrl"]
                           let uid = userpostdetails?["uid"]
                           let pid = userpostdetails?["pid"]
                           let ingredient = userpostdetails?["ingredient"]
                           
                           let userPostsDetails = PostModel(pid: pid as! String?, uid: uid as! String?, recipename: recipename as! String?, pretimehr: preptimehr as! String?, preptimemin: preptimemin as! String?, serving: serving as! String?, level: level as! String?, cuisine: category as! String?, ingred: ingredient as! [String]?, instruction: instruction as! String?, imgurl: imgurl as! String?)
                           
                           self.posts.append(userPostsDetails)
                       }
                   }
                   self.usertabelview.reloadData()
                  
               }
            
            
        })

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        userRef = nil
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Celluser", for: indexPath) as! UserProfTableViewCell
        
        
        //cell.postmodel = posts[indexPath.row]
        
        let postM : PostModel
        postM = posts[indexPath.row]
       // print(posts.count)
        cell.recipename.text = postM.recipename
        cell.cuisinename.text = "Cuisine: \(postM.cuisine!)"
        cell.serving.text = "Serving Size: \(postM.serving!)"
        cell.time.text = "Time: \(postM.pretimehr!):\(postM.preptimemin!)"

        if postM.level == "Simple"{

            cell.level.textColor = UIColor.systemGreen
            cell.level.text = postM.level

        }else if postM.level == "Medium"{

            cell.level.textColor = UIColor.systemYellow
            cell.level.text = postM.level

        }else if postM.level == "Difficult"{

            cell.level.textColor = UIColor.red
            cell.level.text = postM.level
        }

        cell.userProfDelete = self
        cell.postID = postM.pid!
        cell.category = postM.cuisine!
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      let postDetail : PostModel
              postDetail = posts[indexPath.row]
        
        DispatchQueue.main.async {[weak self] in
            let vc = self?.storyboard?.instantiateViewController(identifier: "RecipeViewController") as! RecipeViewController
            vc.recipeID = postDetail.pid!
            self?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func btnDeleteRecipeID(pid: String,category: String) {
        print(pid)
        let alert = UIAlertController(title: "Do you want to delete this recipe?",message: "", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: {(option) in
            alert.dismiss(animated: true, completion: nil)
            
            //TODO: Delete post from Users->Posts
            //NEED: userid->postid
            let userId = Auth.auth().currentUser!.uid
        self.userRef?.child("Users").child(userId).child("Posts").child(pid).removeValue(completionBlock: { (usererror, ref) in
                
                    if usererror != nil {
                        print("Sometihng wrong while deleteing",usererror!)
                    }
                    else{
                      print("Deleted user post")
                }
                })
            
            self.userRef?.child("Posts").child(pid).removeValue(completionBlock: {(error,ref) in
                if error != nil{
                    print("wrong in post")
                }
                else{
                    print("deleted post")
                }
            })
        
            self.userRef?.child("Category").child(category).child("Posts").child(pid).removeValue(completionBlock: {(categoryerror , ref) in
                
                if categoryerror != nil{
                    print("Wrong delete in category")
                }
                else{
                 print("Deleted category")
                }
            })
            
            self.userRef?.child("Comment").child(pid).removeValue(completionBlock: {(commenterror , ref) in
                
                if commenterror != nil{
                    print("Wrong delete in comment")
                }
                else{
                    print("Deleted comment")
                }
                
            })
            
        }))
        
         alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: {(option) in
            alert.dismiss(animated: true, completion: nil)
         }))
        self.present(alert, animated: true, completion: nil)
    }
    

}
