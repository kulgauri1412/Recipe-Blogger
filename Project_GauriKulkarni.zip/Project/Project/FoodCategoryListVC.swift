//
//  FoodCategoryListVC.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/9/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class FoodCategoryListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    deinit {
        print("Retain cycle in FoodCategory")
        postReft = nil
    }
    //Firebase database reference
    var postReft : DatabaseReference?
    var cuisinename = String()
    var postModel = [PostModel]()
    var recipeid = ""
    
    @IBOutlet weak var recipetabel: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        postReft = Database.database().reference().child("Posts")
        
        // Do any additional setup after loading the view.
        //fetch detail from firebase users
        
        postReft?.observeSingleEvent(of: .value, with: {(snapshot) in
            
            if snapshot.childrenCount > 0{
                self.postModel.removeAll()
                for post in snapshot.children.allObjects as![DataSnapshot]{
                    let postdetails = post.value as? [String : AnyObject]
                    let category = postdetails!["category"] as! String
                    
                    if category == self.cuisinename{
                        let recipename = postdetails?["recipename"]
                        let preptimehr = postdetails?["preptimehr"]
                        let preptimemin = postdetails?["preptimemin"]
                        let serving = postdetails?["serving"]
                        let level = postdetails?["setlevel"]
                        let category = postdetails?["category"]
                        let instruction = postdetails?["instruction"]
                        let imgurl = postdetails?["imageUrl"]
                        let uid = postdetails?["uid"]
                        let pid = postdetails?["pid"]
                        let ingredient = postdetails?["ingredient"]
                                               
                        let userPostsDetails = PostModel(pid: pid as! String?, uid: uid as! String?, recipename: recipename as! String?, pretimehr: preptimehr as! String?, preptimemin: preptimemin as! String?, serving: serving as! String?, level: level as! String?, cuisine: category as! String?, ingred: ingredient as! [String]?, instruction: instruction as! String?, imgurl: imgurl as! String?)
                                               
                        self.postModel.append(userPostsDetails)
                    }
                    self.recipetabel.reloadData()
                }
            }
            else{
                print("FoodCategoryListVC no child found")
            }
            
        })

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        postReft = nil
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postModel.count
       }
       
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cellrecipe", for: indexPath) as! CategoryListTableViewCell
        
        let postDetail : PostModel
        postDetail = postModel[indexPath.row]
        
        cell.recipename.text = postDetail.recipename
        cell.cuisinename.text = "Cuisine: \(postDetail.cuisine!)"
        cell.serving.text = "Serving Size: \(postDetail.serving!)"
        cell.time.text = "Time: \(postDetail.pretimehr!):\(postDetail.preptimemin!)"
        if postDetail.level! == "Simple"{
           cell.level?.textColor = UIColor.systemGreen
           cell.level.text = postDetail.level!
        }
        if postDetail.level! == "Medium"{
            cell.level?.textColor = UIColor.systemOrange
            cell.level.text = postDetail.level!
        }
        if postDetail.level! == "Difficult"{
            cell.level?.textColor = UIColor.systemRed
            cell.level.text = postDetail.level!
        }

        return cell
       }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          let postDetail : PostModel
              postDetail = postModel[indexPath.row]
        
        DispatchQueue.main.async {[weak self] in
            let vc = self?.storyboard?.instantiateViewController(identifier: "RecipeViewController") as! RecipeViewController
            vc.recipeID = postDetail.pid!
            self?.navigationController?.pushViewController(vc, animated: true)
        }
    }
        
}
