//
//  SignUpViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/4/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController,UITextFieldDelegate{
    
    //firebase database reference
    var userRef : DatabaseReference!
    
    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var userEmail: UITextField!
    
    @IBOutlet weak var userPassword: UITextField!
    
    //Add users on button Signup
    @IBAction func btnSignUp(_ sender: Any) {
        
        //check valid email id format
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: userEmail.text)
        
        if result == true && userPassword.text!.count >= 6 && userName.text != ""{
            //call function if all condition satisifies
            addUsers()
        }else{
            //alert for password length
            if userPassword.text!.count < 6 {
                let alert = UIAlertController(title: "Password length should be minimum 6", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            //alert for invalid email id
            if result == false {
                let alert = UIAlertController(title: "Please enter valid email address", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            //alert for empty username
            if userName.text == "" {
                let alert = UIAlertController(title: "Please enter username", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Hide keyboard on touch
        super.HideKeyboard()
        userName.delegate = self
        userEmail.delegate = self
        userPassword.delegate = self
        
        //users database reference
        userRef = Database.database().reference().child("Users")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        userRef = nil
    }
    
    //Hide keyboard on retuen key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //function for add Users in firebase database
    func addUsers(){
        
        let uname = userName.text!
        let password = userPassword.text!
        
        print(userEmail.text!)
        
        //check if username is already exists
        userRef.queryOrdered(byChild: "username").queryEqual(toValue: userName.text!).observeSingleEvent(of: .value, with: {(snap) in
            
            //if username is exist show alert
            if snap.exists(){
                let alert = UIAlertController(title: "Username is already exists!", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }//if no matching username found add current user in firebase auth
            else{
               print("insdie else login with firebase auth")
                Auth.auth().createUser(withEmail: self.userEmail.text!, password: self.userPassword.text!, completion: {[weak self](userResult,error) in
                    
                    //get current userid from auth and add user in firebase database
                    if userResult != nil{
                        print(userResult!)
                        let userId = Auth.auth().currentUser!.uid
                        
                        let userDetail = [
                            "id" : userId,
                            "username" : uname,
                            "email" : self!.userEmail.text!,
                            "password" : password]
                        
                        self!.userRef.child(userId).setValue(userDetail)
                        
                        //if user successfully register redirect to dashboard
                        print("success")
                        
                        let main = UIStoryboard(name: "Main", bundle: nil)
                        let mainTBC = main.instantiateViewController(withIdentifier: "MainTabBarController")
                        mainTBC.modalPresentationStyle = .fullScreen
                        self!.present(mainTBC,animated:true,completion: nil)
                        
                    }//if something went wrong while sign up this will show an appropriate error
                    else{
                        if let resultError = error?.localizedDescription{
                            print(resultError)
                            let alert = UIAlertController(title: resultError, message: "", preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                            self!.present(alert, animated: true, completion: nil)
                        }
                    }
                    
                })
            }

        })
        
    }

}
