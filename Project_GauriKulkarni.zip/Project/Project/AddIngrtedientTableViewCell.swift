//
//  AddIngrtedientTableViewCell.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/6/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class AddIngrtedientTableViewCell: UITableViewCell {

    @IBOutlet weak var lbladdingred: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
