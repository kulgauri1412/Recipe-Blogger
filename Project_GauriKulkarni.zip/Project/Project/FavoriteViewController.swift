//
//  FavoriteViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/15/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class FavoriteViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var userRef : DatabaseReference?
    
    var userDetail = [UserModel]()
    var posts = [PostModel]()
    
    var postId = [String]()
    
    @IBOutlet weak var fvrttable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        userRef = Database.database().reference()
        let userId = Auth.auth().currentUser!.uid
        
        userRef?.child("Users").child(userId).child("Favorite").observe(.value, with: {(snapshot) in
            
            if snapshot.childrenCount > 0 {
                print("data is present",snapshot.childrenCount)
                for fvrtId in snapshot.children.allObjects as! [DataSnapshot]{
                    let postid = fvrtId.value! as! String
                    self.userRef?.child("Posts").observe(.value, with: {(snap) in
                        if snap.childrenCount > 0 {
                            self.posts.removeAll()
                            for post in snap.children.allObjects as! [DataSnapshot]{
                                let userpostdetails = post.value as? [String: AnyObject]
                                let pidcheck = userpostdetails?["pid"] as! String
                                
                                if pidcheck == postid{
                                    //print("something is there")
                                    
                                let recipename = userpostdetails?["recipename"]
                                let preptimehr = userpostdetails?["preptimehr"]
                                let preptimemin = userpostdetails?["preptimemin"]
                                let serving = userpostdetails?["serving"]
                                let level = userpostdetails?["setlevel"]
                                let category = userpostdetails?["category"]
                                let instruction = userpostdetails?["instruction"]
                                let imgurl = userpostdetails?["imageUrl"]
                                let uid = userpostdetails?["uid"]
                                let pid = userpostdetails?["pid"]
                                let ingredient = userpostdetails?["ingredient"]
                                    
                              let userPostsDetails = PostModel(pid: pid as! String?, uid: uid as! String?, recipename: recipename as! String?, pretimehr: preptimehr as! String?, preptimemin: preptimemin as! String?, serving: serving as! String?, level: level as! String?, cuisine: category as! String?, ingred: ingredient as! [String]?, instruction: instruction as! String?, imgurl: imgurl as! String?)
                                self.posts.append(userPostsDetails)
                                }
                                self.fvrttable.reloadData()
                            }
                            
                        }else{
                            print("no data in post -fvrtvc")
                        }
                    })
                }
                
            }else{
                self.posts.removeAll()
                print("No data added in fvrt")
                self.fvrttable.reloadData()
            }
            
        })

//
//        userRef?.child("Users").child(userId).child("Favorite").observeSingleEvent(of: .value, with: {(snapshot) in
//            if snapshot.childrenCount > 0{
//                for fvrtId in snapshot.children.allObjects as! [DataSnapshot]{
//                   // print(fvrtId.value!)
//                    let postid = fvrtId.value! as! String
//                    //self.postId.append(pid)
//                    self.posts.removeAll()
//                    self.userRef?.child("Posts").observeSingleEvent(of: .value, with: {(snapshot) in
//                        if snapshot.childrenCount > 0{
//                            for post in snapshot.children.allObjects as! [DataSnapshot]{
//                              let userpostdetails = post.value as? [String: AnyObject]
//                                let pidcheck = userpostdetails?["pid"] as! String
//
//                                if pidcheck == postid {
//
//                                 let recipename = userpostdetails?["recipename"]
//                                 let preptimehr = userpostdetails?["preptimehr"]
//                                 let preptimemin = userpostdetails?["preptimemin"]
//                                 let serving = userpostdetails?["serving"]
//                                 let level = userpostdetails?["setlevel"]
//                                 let category = userpostdetails?["category"]
//                                 let instruction = userpostdetails?["instruction"]
//                                 let imgurl = userpostdetails?["imageUrl"]
//                                 let uid = userpostdetails?["uid"]
//                                 let pid = userpostdetails?["pid"]
//                                 let ingredient = userpostdetails?["ingredient"]
//
//                                 let userPostsDetails = PostModel(pid: pid as! String?, uid: uid as! String?, recipename: recipename as! String?, pretimehr: preptimehr as! String?, preptimemin: preptimemin as! String?, serving: serving as! String?, level: level as! String?, cuisine: category as! String?, ingred: ingredient as! [String]?, instruction: instruction as! String?, imgurl: imgurl as! String?)
//
//                                 self.posts.append(userPostsDetails)
//                                }
//                            }
//                            self.fvrttable.reloadData()
//                        }else{
//                            print("no data")
//                        }
//
//                    })
//
//                }
//
//            }
//            else{
//                print("no data found in fvrt")
//            }
//
//        })
        
        
       
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        userRef = nil
        self.posts.removeAll()
        self.fvrttable.reloadData()
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cellfvrt", for: indexPath) as! FvrtTableViewCell
        
       let postM : PostModel
       postM = posts[indexPath.row]
        //print(posts.count)
        cell.recipename.text = postM.recipename
        cell.cuisine.text = "Cuisine: \(postM.cuisine!)"
        cell.serving.text = "Serving Size: \(postM.serving!)"
        cell.time.text = "Time: \(postM.pretimehr!):\(postM.preptimemin!)"
        if postM.level == "Simple"{
               cell.level.textColor = UIColor.systemGreen
               cell.level.text = postM.level

           }else if postM.level == "Medium"{

               cell.level.textColor = UIColor.systemYellow
               cell.level.text = postM.level

           }else if postM.level == "Difficult"{

               cell.level.textColor = UIColor.red
               cell.level.text = postM.level
           }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let postDetail : PostModel
                 postDetail = posts[indexPath.row]
           
           DispatchQueue.main.async {[weak self] in
               let vc = self?.storyboard?.instantiateViewController(identifier: "RecipeViewController") as! RecipeViewController
               vc.recipeID = postDetail.pid!
               self?.navigationController?.pushViewController(vc, animated: true)
           }
       }

}
