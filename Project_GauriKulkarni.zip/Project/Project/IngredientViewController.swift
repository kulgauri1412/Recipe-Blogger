//
//  IngredientViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/5/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class IngredientViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    
    deinit {
        print("Retain cycle in ingredient list")
    }
    
    var recipename = String()
    var preptimehr = String()
    var preptimemin = String()
    var serving = String()
    var level = String()
    var cuisine = String()
    var ingredientArray = [String]()
   
    @IBOutlet weak var addtableview: UITableView!
    
    @IBAction func btnAddIngredient(_ sender: Any) {
        
        let addIngredAlert = UIAlertController(title: "Add Ingredient", message: "Ingredient with quantity! Eg: 3 cup of rice", preferredStyle: .alert)
        addIngredAlert.addTextField()
        
        let addAction = UIAlertAction(title: "Add", style: .default){(action) in
            let ToAdd = addIngredAlert.textFields![0]
            self.ingredientArray.append(ToAdd.text!)
            //print(self.ingredientArray)
            self.addtableview.reloadData()
        }
        
        let cancelAction = UIAlertAction(title : "Cancel", style: .default)
        
        addIngredAlert.addAction(addAction)
        addIngredAlert.addAction(cancelAction)
        
        present(addIngredAlert,animated: true,completion: nil)
        
    }
    
    @IBAction func btnNextStep(_ sender: Any) {
        
        if !ingredientArray.isEmpty {
            //Next step
       // UserDefaults.standard.set(ingredientArray, forKey: "ingredientArray")
            
        let vc = self.storyboard?.instantiateViewController(identifier: "FinalViewController") as! FinalViewController
        
            vc.recipenameVc = recipename
            vc.preptimehrVC = preptimehr
            vc.preptimeminVC = preptimemin
            vc.servingVC = serving
            vc.levelVC = level
            vc.cuisineVC = cuisine
            vc.ingredientArrayVC = ingredientArray
            
        self.navigationController?.pushViewController(vc, animated: true)
        }
        else{
            let alert = UIAlertController(title: "Please add ingredients", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.setHidesBackButton(true, animated:true)
        print(recipename,preptimehr,preptimemin,level)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
//
//        if let ingredArr = UserDefaults.standard.array(forKey: "ingredientArray") as? [String]{
//
//            ingredientArray = ingredArr
//
//        }else{
//            ingredientArray.removeAll()
//        }
        
        self.navigationItem.setHidesBackButton(true, animated:true);
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ingredientArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addcell", for: indexPath) as! AddIngrtedientTableViewCell
        
        cell.lbladdingred.text = ingredientArray[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            ingredientArray.remove(at: indexPath.row)
            addtableview.reloadData()
        }
    }

}
