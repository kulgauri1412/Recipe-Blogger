//
//  FvrtTableViewCell.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/15/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class FvrtTableViewCell: UITableViewCell {

    @IBOutlet weak var recipename: UILabel!
    
    @IBOutlet weak var cuisine: UILabel!
    @IBOutlet weak var level: UILabel!
    
    @IBOutlet weak var serving: UILabel!
    @IBOutlet weak var time: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
