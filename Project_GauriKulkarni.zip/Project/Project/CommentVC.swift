//
//  CommentVC.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/11/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class CommentVC: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
    
    var postId = String()
    
    
    var commentRef : DatabaseReference?
    var usernameRef : DatabaseReference?
    
    var username = ""
    
    //Comment model
    var commentModel = [CommentModel]()
    
    @IBOutlet weak var commentTextField: UITextField!
    
    @IBOutlet weak var commnettable: UITableView!
    
    @IBAction func btnComment(_ sender: Any) {
        
        //Make comment
        
        if commentTextField.text != nil {
            
            //Create Firebase database to add comment in db
            let commentPost = [
                "comment" : commentTextField.text!,
                "username" : username
                ] as [String : Any]
            
            commentRef?.child("Comment").child(postId).childByAutoId().setValue(commentPost)
            
            commentTextField.text = ""
        }else{
            //Make an alert if text is missing
            print("Nil textfield")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        super.HideKeyboard()
        commentTextField.delegate = self
        //Database comment node reference
        commentRef = Database.database().reference()
        
        //get username from firebase user node
        usernameRef = Database.database().reference().child("Users")
        let userId = Auth.auth().currentUser!.uid
        usernameRef?.child(userId).observeSingleEvent(of: .value, with: {(snapshot) in
           
            if snapshot.childrenCount > 0{
                
                let userdta = snapshot.value as! [String: Any]

                let uname = userdta["username"] as! String
                
                self.username = String(uname)
                
            }
            
        })
        
        commentRef?.child("Comment").child(postId).observe(.value, with: {(snapshot) in
          if snapshot.childrenCount > 0{
                self.commentModel.removeAll()
                for snap in snapshot.children.allObjects as! [DataSnapshot]{
                    let commentpost = snap.value as? [String : Any]
                    let comment = commentpost!["comment"] as? String
                    let username = commentpost!["username"] as? String

                    let addCommentToModel = CommentModel(comment: comment!,username: username!)
                    
                    self.commentModel.append(addCommentToModel)
                    
                }
                self.commnettable.reloadData()
            }else{
                print("Comment tabel no data yet added")
            }
        })
//
//        commentRef?.child("Comment").child(postId).observeSingleEvent(of: .value, with: {(snapshot) in
//            if snapshot.childrenCount > 0{
//                self.commentModel.removeAll()
//                for snap in snapshot.children.allObjects as! [DataSnapshot]{
//                    let commentpost = snap.value as? [String : Any]
//                    let comment = commentpost!["comment"] as? String
//                    let username = commentpost!["username"] as? String
//
//                    let addCommentToModel = CommentModel(comment: comment!,username: username!)
//
//                    self.commentModel.append(addCommentToModel)
//
//                }
//               DispatchQueue.main.async{
//                    self.commnettable.reloadData()
//                }
//            }else{
//                print("Comment tabel no data yet added")
//            }
//
//        })
    }
    
    //Hide keyboard on return key press
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return commentModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cellcomment", for: indexPath) as! CommentTableCell
        
        let commentM = commentModel[indexPath.row]
        cell.username.text = "Username: \(commentM.username!)"
        cell.comment.text = commentM.comment
        
        return cell
    }

}
