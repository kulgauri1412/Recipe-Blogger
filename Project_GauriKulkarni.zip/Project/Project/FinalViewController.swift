//
//  FinalViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/6/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class FinalViewController: UIViewController,UITextViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    var database : DatabaseReference!
    var newPostRef : DatabaseReference!
    
    var recipenameVc = String()
    var preptimehrVC = String()
    var preptimeminVC = String()
    var servingVC = String()
    var levelVC = String()
    var cuisineVC = String()
    var ingredientArrayVC = [String]()
    
    var activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView()
    
    @IBOutlet weak var recipeInstruction: UITextView!
    
    @IBOutlet weak var foodImage: UIImageView!
    
    var downlodImageURL = ""
    var postId = ""
 
    @IBAction func btnPickUpImage(_ sender: Any) {
        //Upload image
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    //function for image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
            foodImage.image = image
            let imageData = image.jpegData(compressionQuality: 0)
            let imageStorageRef = Storage.storage().reference().child("PostImages")
            let newImageRef = imageStorageRef.child(postId)
            let metaData = StorageMetadata()
            metaData.contentType = "image/jpeg"
            newImageRef.putData(imageData!, metadata: metaData, completion:{[weak self](metadata , error) in
                
                if error == nil{
                    newImageRef.downloadURL(completion: { (url , error) in
                        //completion(url!)
                        self?.downlodImageURL = url!.absoluteString
                    })
                }
                else{
                    print("error line 161 finalviewcontroller")
                }
                
            })
            
        }
        self.dismiss(animated: true, completion: nil)
    }
    

    @IBAction func PostRecipe(_ sender: Any) {
        //upload recipe on firebase database
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.large
        view.addSubview(activityIndicator)
        
        if recipeInstruction.text != ""  && foodImage.image != nil && downlodImageURL != "" {
                activityIndicator.startAnimating()

            
            self.saveImage(recipename: self.recipeInstruction.text!, downlodImageURL: self.downlodImageURL){ error in

                if error == nil {

                    self.recipeInstruction.text = ""
                    self.foodImage.image = nil

                    self.activityIndicator.stopAnimating()

                    //success alert
                    let alert = UIAlertController(title: "Your recipe uploaded successfully!", message: "", preferredStyle: UIAlertController.Style.alert)
                            let cancelAction = UIAlertAction(title: "Ok", style: .cancel) { (action) -> Void in
                    DispatchQueue.main.async {[weak self] in
                        let vc = self?.storyboard?.instantiateViewController(identifier: "AddRecipeViewController") as! AddRecipeViewController
                        self?.navigationController?.pushViewController(vc, animated: true)
                                }
                        }
                    alert.addAction(cancelAction)
                    self.present(alert, animated: true, completion: nil)

                }else if error != nil {
                    let alert = UIAlertController(title: "Something went wrong while uploading post.Please try again!", message: "", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                        }

                }


               }else{
                
            if foodImage.image == nil || recipeInstruction.text == "" {
                    let alert = UIAlertController(title: "All fields are mandetory!", message: "", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }else if  foodImage.image != nil && downlodImageURL == ""{
                   let alert = UIAlertController(title: "Somwthing went wrong! Please select image again", message: "", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
              }
        
    }
    
    //Upload Image in storage get downloaded url //Remove this method
    func uploadImage(_ foodImage : UIImage, completion: @escaping ((_ url : URL) -> ())){
        //Need  image URL for stograge and store image in firebase storage
        let imageData = foodImage.jpegData(compressionQuality: 0)
        let imageStorageRef = Storage.storage().reference().child("PostImages")
        let newImageRef = imageStorageRef.child(postId)
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpeg"
        newImageRef.putData(imageData!, metadata: metaData, completion:{(metadata , error) in
            
            if error == nil{
                newImageRef.downloadURL(completion: { (url , error) in
                    completion(url!)
                })
            }
            else{
                print("error line 161 finalviewcontroller")
            }
            
        })
    }
    
    //Save image in firebase using completion handler
    
    func saveImage(recipename : String ,downlodImageURL : String,completion: @escaping (Error?)-> Void){
        
        print("downloadin url: \(downlodImageURL)")
        
        //firebase call
        let userId = Auth.auth().currentUser!.uid // current loged in user id
        
        let recipename = recipenameVc
        let preptimehr = preptimehrVC
        let preptimemin = preptimeminVC
        let serving = servingVC
        let setlevel = levelVC
        let category = cuisineVC
        let ingredient = ingredientArrayVC
 
        //For Post node
        let postDetails = [
            "pid" : postId,
            "recipename" : recipename,
            "preptimehr" : preptimehr,
            "preptimemin" : preptimemin,
            "serving" : serving,
            "setlevel" : setlevel,
            "category" : category,
            "ingredient" : ingredient,
            "instruction" : recipeInstruction.text!,
            "imageUrl" : downlodImageURL,
            "uid" : userId] as [String : AnyObject]

        
        //For Categoery node
        
        let categoryRef = database.child("Category").child(category).child("Posts")
        let categoryPost = [postId : postId]
        
        
        //For Users node
        
        let usersRef = database.child("Users").child(userId).child("Posts")
        let usersPost = [postId : postId]
        
        newPostRef.setValue(postDetails)
        categoryRef.updateChildValues(categoryPost)
        usersRef.updateChildValues(usersPost)
        
        print("Success in save post")
        
        completion(nil)
        return
    }
    
    override func viewDidLoad() {
       
        super.viewDidLoad()
        
        super.HideKeyboard()
        recipeInstruction.delegate = self
        
        self.navigationItem.setHidesBackButton(true, animated:true)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //print(recipenameVc,ingredientArrayVC)
        
        //users database reference
        database = Database.database().reference()
        
        newPostRef =  database.child("Posts").childByAutoId()
        postId = newPostRef.key! // postid
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        database = nil
        newPostRef = nil
        
        //Clear all stored reference
//        recipenameVc = ""
//        preptimehrVC = ""
//        preptimeminVC = ""
//        servingVC = ""
//        levelVC = ""
//        cuisineVC = ""
//        ingredientArrayVC = []
    }
    
    

}
