//
//  UserProfTableViewCell.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/8/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

protocol buttonProtocol {
    func btnDeleteRecipeID(pid : String,category: String)
}

class UserProfTableViewCell: UITableViewCell {
    

    @IBOutlet weak var cuisinename: UILabel!
    @IBOutlet weak var level: UILabel!
    @IBOutlet weak var recipename: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var serving: UILabel!
    
    var userProfDelete:buttonProtocol?
    var postID : String = ""
    var category : String = ""
       
    
    @IBAction func btnDeleteRecipe(_ sender: Any) {
        self.userProfDelete?.btnDeleteRecipeID(pid: postID, category: category)
    }
    
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
