//
//  ViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/3/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

extension UIViewController{
    func HideKeyboard(){
        let Tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(DismissKeyboard))
        
        view.addGestureRecognizer(Tap)
    }
    @objc func DismissKeyboard(){
        view.endEditing(true)
    }
}

class ViewController: UIViewController,UITextFieldDelegate {

    //firebase database reference
    var userRef : DatabaseReference!
    
    @IBOutlet weak var userEmail: UITextField!
    
    @IBOutlet weak var userPassword: UITextField!
    
    //Button for login in application
    @IBAction func btnLogin(_ sender: Any) {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: userEmail.text)
               
        if result == true && userPassword.text!.count >= 6 {
            //call function login if all condition satisifies
            login()
            
        }else{
          //alert for invalid email id
            if result == false {
                let alert = UIAlertController(title: "Please enter valid email address", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            //alert for password length
            if userPassword.text! == ""  || userPassword.text!.count < 6{
                let alert = UIAlertController(title: "Please enter valid password", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    //Button for SignupViewController: Using segue in main story board
    @IBAction func btnSignUp(_ sender: Any) {
        
        //performSegue(withIdentifier: "SignUpViewController", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Hide keyboard on touch
        super.HideKeyboard()
        userEmail.delegate = self
        userPassword.delegate = self
        
        //users database reference
        userRef = Database.database().reference().child("Users")
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        userRef = nil
    }
    
    //Hide keyboard on return key press
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //Login function with firebase authentication
    func login(){
        Auth.auth().signIn(withEmail: userEmail.text!, password: userPassword.text!) { [weak self] authResult, error in
            if authResult != nil {
                //if user successfully login redirect to dashboard
                print("success")
                
               // let userId = Auth.auth().currentUser!.uid
                
                //UserDefaults.standard.set(userId, forKey: "userId")
                
                DispatchQueue.main.async {[weak self] in
                    let main = UIStoryboard(name: "Main", bundle: nil)
                    let mainTBC = main.instantiateViewController(withIdentifier: "MainTabBarController")
                    mainTBC.modalPresentationStyle = .fullScreen
                    self!.present(mainTBC,animated:true,completion: nil)
                }
                
                
            }//something went wrong show an error alert
            else{
                if let errorResult = error?.localizedDescription{
                    let alert = UIAlertController(title: errorResult, message: "", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                    self!.present(alert, animated: true, completion: nil)
                }
            }
        }
    }

}

