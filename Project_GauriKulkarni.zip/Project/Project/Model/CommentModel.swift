//
//  CommentModel.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/11/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import Foundation
import UIKit

class CommentModel{
    
    var comment:String?
    var username:String?
    
    init(comment:String,username:String) {
        self.comment = comment
        self.username = username
    }
}
