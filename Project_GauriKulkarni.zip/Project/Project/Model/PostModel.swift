//
//  PostModel.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/8/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import Foundation
import UIKit

class PostModel{
    var pid :String?
    var uid : String?
    var recipename :String?
    var pretimehr :String?
    var preptimemin :String?
    var serving :String?
    var level :String?
    var cuisine :String?
    var ingred : [String]?
    var instruction :String?
    var imgurl  :String?
    
    init(pid:String?,uid:String?,recipename:String?,pretimehr:String?,preptimemin:String?,serving:String?,level:String?,cuisine:String?,ingred:[String]?,instruction:String?,imgurl:String?) {
        
        self.pid = pid
        self.uid = uid
        self.recipename = recipename
        self.pretimehr = pretimehr
        self.preptimemin = preptimemin
        self.serving = serving
        self.level = level
        self.cuisine = cuisine
        self.ingred = ingred
        self.instruction = instruction
        self.imgurl = imgurl
    }
    
    deinit {
        print("deinit postmodel")
    }
}
