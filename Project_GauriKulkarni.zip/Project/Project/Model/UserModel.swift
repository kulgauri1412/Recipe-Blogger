//
//  UserModel.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/8/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import Foundation
import UIKit

class UserModel{
    var username :String?
    var id :String?
    var userposts : [String]?
    
    init(username : String?,id:String?,userposts:[String]?) {
        self.username = username
        self.id = id
        self.userposts = userposts
    }
    deinit {
        print("Deinit usermodel")
    }
}
