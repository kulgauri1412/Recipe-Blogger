//
//  RecipeViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/10/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Firebase

class RecipeViewController: UIViewController{
  
    deinit {
        print("Retain cycle in RecipeviewController")
    }
    
    //Firebase database reference
    var postReft : DatabaseReference?
    var userRef: DatabaseReference?
    
    var recipeID = String()
    var flag = 0
    
    //var imgUrl = String()
    @IBAction func btnComment(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "CommentVC") as! CommentVC
        vc.postId = recipeID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBOutlet weak var foodImage: UIImageView!
    
    @IBOutlet weak var lblFavorite: UIButton!
    
    @IBOutlet weak var level: UILabel!
    
    
    @IBAction func wishlist(_ sender: Any) {
       let userId = Auth.auth().currentUser!.uid
        
        if flag == 0{
            let favorite = [userId : userId]
            postReft?.child("Favorite").updateChildValues(favorite)
            
            let favrotePost = [recipeID : recipeID]
            userRef?.child(userId).child("Favorite").updateChildValues(favrotePost)
            
            flag = 1
            
            lblFavorite.setTitle("Remove from Favorite", for: .normal)
            
        }
        else if flag == 1{
            let userId = Auth.auth().currentUser!.uid
            
            postReft?.child("Favorite").child(userId).removeValue(completionBlock: {(postfvrterror , ref) in
                if postfvrterror != nil{
                    print("Error in removing fvrt")
                }
            })
            userRef?.child(userId).child("Favorite").child(recipeID).removeValue(completionBlock: {(userposterror, ref) in
                if userposterror != nil{
                    print("Error in removing user fvrt")
                }
            })
            
            flag = 0
                       
           lblFavorite.setTitle("Add to Favorite", for: .normal)
            
        }
        
        
    }
    
    @IBOutlet weak var recipename: UILabel!
    
    
    @IBOutlet weak var ingredtableview: UITableView!
    
    @IBOutlet weak var recipeprocedure: UITextView!
    
    @IBOutlet weak var serving: UILabel!
    
    @IBOutlet weak var time: UILabel!

    
    @IBOutlet weak var ingredText: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        userRef = Database.database().reference().child("Users")
        postReft = Database.database().reference().child("Posts").child(recipeID)
        
        postReft?.observeSingleEvent(of: .value, with: {(snapshot) in
            if snapshot.childrenCount > 0{
                let post = snapshot.value as? NSDictionary
                self.recipename.text = post?["recipename"] as? String
                self.recipeprocedure.text = post?["instruction"] as? String
                let ingred = post?["ingredient"] as! [String]
                let stringIngred = ingred.joined(separator:",")
                let newIngred = stringIngred.replacingOccurrences(of: ",", with: "\n")
                self.ingredText.text = newIngred
                self.serving.text = "Serving: \(post?["serving"] as! String)"
                self.time.text = "Time: \(post?["preptimehr"] as! String):\(post?["preptimemin"] as! String)"
                let setlevel = post?["setlevel"] as! String
                
                if setlevel == "Simple"{

                    self.level.textColor = UIColor.systemGreen
                    self.level.text = setlevel

                }else if setlevel == "Medium"{

                    self.level.textColor = UIColor.systemYellow
                    self.level.text = setlevel

                }else if setlevel == "Difficult"{

                    self.level.textColor = UIColor.red
                    self.level.text = setlevel
                }
                
                let imgUrl = post?["imageUrl"] as! String
                //image load from firebase database storage
                //print(imgUrl)
                //This condition is for safer side to check in any case image is url uploaded null then it will help from crash
                if imgUrl != "" {
                    //print("image is there",post?["imageUrl"])
                    let storageRef = Storage.storage().reference(forURL: post?["imageUrl"] as! String)
                    storageRef.getData(maxSize: 1 * 1024 * 1024) { (data, error) -> Void in
                            //print(data)
                        if data != nil{
                                //counter += 1
                        var pic = UIImage(data: data!)
                            DispatchQueue.main.async {[weak self] in
                                    self?.foodImage.image = pic
                                    pic = nil
                                }
                            }
                        else if error != nil {
                            self.foodImage.image = UIImage(named: "other")
                            print(error as Any)
                        }
                    }
                }else{
                    print("Inside no image")
                    self.foodImage.image = UIImage(named: "other")
                }

  
            }
            else{
            print("Error while loading data")
            }
        })
        
        postReft?.child("Favorite").observeSingleEvent(of: .value, with: {(snapshot) in
         if snapshot.childrenCount > 0{
                for fvrt in snapshot.children.allObjects as! [DataSnapshot]{
                   
                 let userId = Auth.auth().currentUser!.uid
                    let frvtlistId = fvrt.value as! String
                    if userId == frvtlistId{
                        
                        self.flag = 1
                        
                        self.lblFavorite.setTitle("Remove from Favorite", for: .normal)
                    }
                    
                }
            }
            else{
                print("no dtaa")
            }
            
        })
        
//        postReft?.child("Favorite").observe(.value, with: {(snapshot) in
//    
//            if snapshot.childrenCount > 0{
//                for fvrt in snapshot.children.allObjects as! [DataSnapshot]{
//                   
//                 let userId = Auth.auth().currentUser!.uid
//                    let frvtlistId = fvrt.value as! String
//                    if userId == frvtlistId{
//                        
//                        self.flag = 1
//                        
//                        self.lblFavorite.setTitle("Remove from Favorite", for: .normal)
//                    }
//                    
//                }
//            }
//            else{
//                print("no dtaa")
//            }
//            
//        })
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        postReft = nil
        print("Recipeview kill postref")
    }
    

}
