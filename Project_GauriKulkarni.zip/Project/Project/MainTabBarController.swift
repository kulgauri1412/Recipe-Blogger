//
//  MainTabBarController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/4/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
