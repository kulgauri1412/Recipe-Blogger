//
//  AddRecipeViewController.swift
//  Project
//
//  Created by Gauri Kulkarni on 12/5/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

extension String {
    var isInt: Bool {
        return Int(self) != nil
    }
}

class AddRecipeViewController: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
    
    deinit {
        print("Retain cycle in addrecipeview controller")
    }
    
    
    var FoodCategory = ["American","Chinese","Italian","Indian","Other"]
    
    var category = ""
    
    var levelFlag = 0
    
    @IBOutlet weak var recipeName: UITextField!
    @IBOutlet weak var prepTimeHr: UITextField!
    @IBOutlet weak var perpTimeMin: UITextField!
    @IBOutlet weak var servingSize: UITextField!
    @IBOutlet weak var btnDifficultOt: UIButton!
    @IBOutlet weak var btnMediumOt: UIButton!
    @IBOutlet weak var btnSimpleOt: UIButton!
    
    var setlevel = ""
    
    @IBAction func btnDifficult(_ sender: Any) {
        
        levelFlag = 1
        
        //Remove shadow part for other buttons while clicking this one
        btnMediumOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnMediumOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnMediumOt.layer.shadowOpacity = 0
        btnMediumOt.layer.shadowRadius = 0
        btnMediumOt.layer.masksToBounds = false
        
        btnSimpleOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnSimpleOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnSimpleOt.layer.shadowOpacity = 0
        btnSimpleOt.layer.shadowRadius = 0
        btnSimpleOt.layer.masksToBounds = false
        
        //Shadow part for selction of level
        if levelFlag == 1{
            btnDifficultOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.90).cgColor
            btnDifficultOt.layer.shadowOffset = CGSize(width: 0, height: 5)
            btnDifficultOt.layer.shadowOpacity = 2.0
            btnDifficultOt.layer.shadowRadius = 10.0
            btnDifficultOt.layer.masksToBounds = false
            
            setlevel = "Difficult"
        }
    }
    
    @IBAction func btnMedium(_ sender: Any) {
        
        levelFlag = 1
        //Remove shadow part for other buttons while clicking this one
        btnDifficultOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnDifficultOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnDifficultOt.layer.shadowOpacity = 0
        btnDifficultOt.layer.shadowRadius = 0
        btnDifficultOt.layer.masksToBounds = false
        
        btnSimpleOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnSimpleOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnSimpleOt.layer.shadowOpacity = 0
        btnSimpleOt.layer.shadowRadius = 0
        btnSimpleOt.layer.masksToBounds = false
        
        if levelFlag == 1{
            //Shadow part for selction of level
            btnMediumOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.90).cgColor
            btnMediumOt.layer.shadowOffset = CGSize(width: 0, height: 5)
            btnMediumOt.layer.shadowOpacity = 2.0
            btnMediumOt.layer.shadowRadius = 10.0
            btnMediumOt.layer.masksToBounds = false
                   
            setlevel = "Medium"
        }
        
    }
    
    @IBAction func btnSimple(_ sender: Any) {
        levelFlag = 1
        //Remove shadow part for other buttons while clicking this one
        btnDifficultOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnDifficultOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnDifficultOt.layer.shadowOpacity = 0
        btnDifficultOt.layer.shadowRadius = 0
        btnDifficultOt.layer.masksToBounds = false
        
        btnMediumOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnMediumOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnMediumOt.layer.shadowOpacity = 0
        btnMediumOt.layer.shadowRadius = 0
        btnMediumOt.layer.masksToBounds = false
        
        if levelFlag == 1{
            //Shadow part for selction of level
            btnSimpleOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.90).cgColor
            btnSimpleOt.layer.shadowOffset = CGSize(width: 0, height: 5)
            btnSimpleOt.layer.shadowOpacity = 2.0
            btnSimpleOt.layer.shadowRadius = 10.0
            btnSimpleOt.layer.masksToBounds = false
        
            setlevel = "Simple"
        }
        
    }
    
    @IBOutlet weak var foodCategory: UIPickerView!
    
    @IBOutlet weak var showCuisine: UILabel!
    
    
    @IBAction func btnNextStep(_ sender: Any) {
        
        //check all fields are valied and not empty
        
        if recipeName.text != "" && prepTimeHr.text != "" &&  perpTimeMin.text != "" && servingSize.text != "" && setlevel != "" && showCuisine.text != "" && prepTimeHr.text!.count == 2 && prepTimeHr.text?.isInt == true && perpTimeMin.text!.count == 2 && perpTimeMin.text?.isInt == true && servingSize.text!.count <= 2 && servingSize.text?.isInt == true && category != ""{
            
             let vc = self.storyboard?.instantiateViewController(identifier: "IngredientViewController") as! IngredientViewController
            vc.recipename = recipeName.text!
            vc.preptimehr = prepTimeHr.text!
            vc.preptimemin = perpTimeMin.text!
            vc.serving = servingSize.text!
            vc.level = setlevel
            vc.cuisine = showCuisine.text!
            self.navigationController?.pushViewController(vc, animated: true)
  
        }
        else{
           // print("All fields are mandatory")
            if recipeName.text == ""{
                let alert = UIAlertController(title: "Please enter recipe name", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else if prepTimeHr.text == "" || prepTimeHr.text!.count > 2 || prepTimeHr.text?.isInt == false || prepTimeHr.text!.count != 2 {
                let alert = UIAlertController(title: "Please enter prep time in hours(Ex: if time is in minute add '00' or 02 or 10)", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }
            else if perpTimeMin.text == "" || perpTimeMin.text!.count > 2 || perpTimeMin.text?.isInt == false || perpTimeMin.text!.count != 2 {
                let alert = UIAlertController(title: "Please enter prep time in minutes(Ex: Add '00' or 02 or 10)", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }
            else if servingSize.text == "" || servingSize.text!.count > 2 || servingSize.text?.isInt == false{
                let alert = UIAlertController(title: "Please enter serving size for recipe in number(Ex: 2 or 12)", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }
            else if setlevel == "" {
                let alert = UIAlertController(title: "Please select recipe level", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            else if showCuisine.text == "" || category == ""{
                let alert = UIAlertController(title: "Please select recipe cuisine category", message: "", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //hide back navigation button
        
        self.navigationItem.setHidesBackButton(true, animated:true)
        
        //Hide keyboard on touch
        super.HideKeyboard()
        recipeName.delegate = self
        prepTimeHr.delegate = self
        perpTimeMin.delegate = self
        servingSize.delegate = self
    
        
        // Make all buttons without shodow
        if levelFlag == 0{
        btnDifficultOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnDifficultOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnDifficultOt.layer.shadowOpacity = 0
        btnDifficultOt.layer.shadowRadius = 0
        btnDifficultOt.layer.masksToBounds = false
        
        btnMediumOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnMediumOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnMediumOt.layer.shadowOpacity = 0
        btnMediumOt.layer.shadowRadius = 0
        btnMediumOt.layer.masksToBounds = false
            
        btnSimpleOt.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0).cgColor
        btnSimpleOt.layer.shadowOffset = CGSize(width: 0, height: 0)
        btnSimpleOt.layer.shadowOpacity = 0
        btnSimpleOt.layer.shadowRadius = 0
        btnSimpleOt.layer.masksToBounds = false
        }
       
    }
   
        
    override func didReceiveMemoryWarning() {
        print("Memory warning")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //self.dismiss(animated: true, completion: nil)
    }
    
    //Hide keyboard on retuen key
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //Picker view option
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return FoodCategory[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return FoodCategory.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        category = FoodCategory[row]
        showCuisine.text = category
        
    }
  

}
